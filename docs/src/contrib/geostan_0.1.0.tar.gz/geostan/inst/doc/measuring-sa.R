## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  fig.align = "center",
  fig.width = 3.5,
  fig.height = 3,
  comment = "#>"
)

## ----setup, message = FALSE, warning = FALSE----------------------------------
library(geostan)
library(sf)
library(ggplot2)
data("georgia")

## ----fig.width = 7------------------------------------------------------------
sp_diag(georgia$college, georgia, name = "College (%)")

## -----------------------------------------------------------------------------
mean(georgia$college)

## -----------------------------------------------------------------------------
weighted.mean(georgia$college, w = georgia$population)

## -----------------------------------------------------------------------------
C <- shape2mat(georgia, style = "W")
moran_plot(georgia$college, C)

## -----------------------------------------------------------------------------
mc(georgia$college, C)

## -----------------------------------------------------------------------------
moran_plot(georgia$college, shape2mat(georgia, "B"))

## -----------------------------------------------------------------------------
Li <- lisa(georgia$college, C)
head(Li)

## -----------------------------------------------------------------------------
c(mc(georgia$college, C), mean(Li$Li))

## -----------------------------------------------------------------------------
rho <- aple(georgia$ICE, C)
n <- nrow(georgia)
ess <- n_eff(rho = rho, n = n)
c(nominal_n = n, rho = rho, ESS = ess)

