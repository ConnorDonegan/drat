library(testthat)
test_check("geostan")
